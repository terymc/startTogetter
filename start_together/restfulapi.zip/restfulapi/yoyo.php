

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script>
    
    $.ajax({
                                url: 'http://localhost:3000/projects',
                                contentType: 'application/json',
                                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                                success: function (response) {
                                    
                                        // console.log(response)
                                         console.log(response)
                                    

                                },
                                error: function (error) {
                                    console.log(error);
                                }
                            });
</script>
